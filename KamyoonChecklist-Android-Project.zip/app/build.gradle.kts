plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.kamyoon.checklist"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.kamyoon.checklist"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
